<?php
// Heading
$_['heading_title']    = 'Pilibaba Checkout Button';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Pilibaba Checkout Button module!';
$_['text_edit']        = 'Edit Pilibaba Checkout Button Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Pilibaba Checkout Button module!';